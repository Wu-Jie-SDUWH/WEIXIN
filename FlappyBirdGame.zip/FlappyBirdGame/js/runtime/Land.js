//不断移动的陆地
import {Sprite} from "../base/Sprite.js";
import {Director} from "../Director.js";
import {DataStore} from "../base/DataStore.js";

// Land类继承自父类Sprite
export class Land extends Sprite {

    constructor() {
        const image = Sprite.getImage('land');  // 把land图片放置在canvas上
        super(image, 0, 0,
            image.width, image.height,
            0, DataStore.getInstance().canvas.height - image.height,
            image.width, image.height);
        //地板的水平变化坐标
        this.landX = 0;
        //地板的移动速度
        this.landSpeed = Director.getInstance().moveSpeed;
    }

    draw() {
        this.landX = this.landX + this.landSpeed;
        if (this.landX > (this.img.width - DataStore.getInstance().canvas.width)) {
            this.landX = 0;  // 当land图片最右端到达canvas边界时，使图片开始循环。
        }
        super.draw(this.img,
            this.srcX,
            this.srcY,
            this.srcW,
            this.srcH,
            -this.landX,  // 陆地从右往左移动，坐标递减故用负
            this.y,
            this.width,
            this.height)
    }

}