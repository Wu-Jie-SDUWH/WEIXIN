//背景
import {Sprite} from "../base/Sprite.js";
import {DataStore} from "../base/DataStore.js";

// BackGround类继承自父类Sprite
export class BackGround extends Sprite {
    constructor() {
        const image = Sprite.getImage('background');
        super(image,
            0, 0,   // 开始剪裁的位置，即最顶端
            image.width, image.height,   // 剪裁一整张图
            0, 0,
            DataStore.getInstance().canvas.width, 
            DataStore.getInstance().canvas.height);
    }
}